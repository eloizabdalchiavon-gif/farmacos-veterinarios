import React, { useState } from "react";

const sections = [
  "Antibióticos",
  "Anti-inflamatórios",
  "Vacinas",
  "Vermífugos",
  "Hormônios",
  "Vias"
];

export default function App() {
  const [step, setStep] = useState(0);

  return (
    <div className="container">
      <h1>Guia de Fármacos Veterinários</h1>

      <div>
        <button onClick={() => setStep(s => Math.max(s-1,0))}>Anterior</button>
        <button onClick={() => setStep(s => Math.min(s+1,sections.length-1))}>Próximo</button>
      </div>

      <div className="card">
        <h2>{sections[step]}</h2>

        {step===0 && <ul>
          <li>Oxitetraciclina</li>
          <li>Penicilina</li>
          <li>Enrofloxacina</li>
          <li>Sulfonamidas</li>
        </ul>}

        {step===1 && <ul>
          <li>Flunixin</li>
          <li>Meloxicam</li>
          <li>Dexametasona</li>
        </ul>}

        {step===2 && <ul>
          <li>Febre aftosa</li>
          <li>Brucelose</li>
          <li>Tétano</li>
          <li>Influenza equina</li>
        </ul>}

        {step===3 && <ul>
          <li>Ivermectina</li>
          <li>Albendazol</li>
          <li>Moxidectina</li>
        </ul>}

        {step===4 && <ul>
          <li>Ocitocina</li>
          <li>PGF2α</li>
          <li>GnRH</li>
        </ul>}

        {step===5 && <ul>
          <li>IM – pescoço</li>
          <li>SC – cervical</li>
          <li>IV – jugular</li>
        </ul>}
      </div>
    </div>
  );
}